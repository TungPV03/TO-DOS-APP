import React, { PureComponent } from "react";
import '../CSS/Todos_List.css';
import '../CSS/CSS Dark Mode/TodosListDark.css'
import SingleTask from "./SingleTask";
import { DARK_CLASS_NAME, ThemeContext } from "./theme-context";

class TodosList extends PureComponent {
    constructor(props){
        super(props);
        this.state = {
            displayTasks : [],
            currentPage : 1,
            loadMore: true
        };
    }
    
    componentDidMount(){
        window.addEventListener('scroll', this.loadMoreItem);
        const lastTaskOfFirstPage = this.props.tasks.length < 15 ? this.props.tasks.length : 15;
        this.setState({displayTasks: this.props.tasks.slice(0,lastTaskOfFirstPage), loadMore : false});
    }

    componentWillUnmount(){
        window.removeEventListener('scroll', this.loadMoreItem);
    }

    loadMoreItem = () => {
        const {currentPage} = this.state;
        const {tasks} = this.props;
        const totalPage = Math.ceil(tasks.length/ 15);
        if (currentPage < totalPage){
            const newPage = currentPage + 1;
            const displayTasks = [...this.state.displayTasks, ...tasks.slice((newPage - 1) * 15, newPage * 15)];
            this.setState({ displayTasks, loadMore: false, currentPage: newPage });
        }
    }
    
    handleScroll = () => {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
            this.loadMoreItem();
        }
    } 
     
    // tasksOfCurrentPage(tasks,currentPage){
    //     const firstTaskOfPage = (currentPage - 1)*10;
    //     const lastTaskOfPage = currentPage * 10 - 1;
    //     const currentTasks = tasks.slice(firstTaskOfPage,lastTaskOfPage + 1);
    //     return currentTasks;
    // }

    render() {
        const {tasks,currentPage} = this.props;
        const currentTasks = this.tasksOfCurrentPage(tasks,currentPage);
        const {displayTasks} = this.state;
        const {isDarkMode} = this.context;
        //console.log(displayTasks);
        if(tasks.length === 0) return null;
        return (
            <div className={"to-do-item-container" + (isDarkMode? DARK_CLASS_NAME : '')}>
                {displayTasks.map((task,index) =>(
                        <SingleTask
                            done={task.done} 
                            key={task.content + index}
                            task={task} index={task.oldIndex}
                            {...this.props}                 
                        />
                ))}
            </div>
        )
    }
}

TodosList.contextType = ThemeContext;

export default TodosList;
